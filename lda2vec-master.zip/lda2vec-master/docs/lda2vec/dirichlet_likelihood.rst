lda2vec.dirichlet_likelihood module
-----------------------------------

.. automodule:: lda2vec.dirichlet_likelihood
    :members:
    :undoc-members:
    :show-inheritance:
