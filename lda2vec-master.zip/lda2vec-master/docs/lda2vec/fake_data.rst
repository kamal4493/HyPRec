lda2vec.fake_data module
------------------------

.. automodule:: lda2vec.fake_data
    :members:
    :undoc-members:
    :show-inheritance:
